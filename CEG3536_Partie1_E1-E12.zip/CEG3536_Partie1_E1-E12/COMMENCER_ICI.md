# Commencer ici : Partie I E1-E12

1. Lire **GUIDE_DETAILLE_PARTIE1.md** dans ce dossier, du début jusqu'aux vérifications finales.
2. Importer ce dossier entier dans STM32CubeIDE. Le nom interne Eclipse du projet est **CEG3536_Projet** comme dans le complément du professeur. Si vous souhaitez importer **les deux versions simultanément**, choisissez deux workspaces IDE séparés pour éviter la collision des noms.
3. Exécuter les tests hôte dans **hote/** : make evq tableau.
4. Programmer la carte **uniquement après Build Project sans erreur et après les précautions de sécurité**.
5. Compléter la table TouchPad et L4A_VARIANTE d'après les mesures et les informations réelles de votre équipe. Les essais avec matériel sont encore à faire.

Le fichier **LISEZMOI.md** original du professeur est conservé comme référence; ses mentions « squelette à compléter » décrivent l'archive d'origine. **GUIDE_DETAILLE_PARTIE1.md** décrit la version de travail de ce ZIP.
