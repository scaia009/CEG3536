/* ---------------------------------------------------------------------------
 * main.c — programme principal en C (CEG 3536, laboratoire 3) — CORRIGÉ
 *
 * Remplace main.s : initialise la couche assembleur (laboratoires 1 et 2),
 * puis les pilotes C (ADC/DMA, LPUART1, DWT), et exécute une boucle cadencée
 * par tick_1ms (E1, E10) :
 *   production d'événements (boutons, E-Stop, encodeur, consigne, télémétrie)
 *   -> consommation par la machine à états -> sorties -> émission série.
 * Commandes série facultatives (un caractère) : z = remise à zéro des
 * compteurs ; t = 40 événements de test (saturation de la file, E12) ;
 * q = autotest de la file (E11) ; b = banc de comparaison L3-A (en ARRÊT).
 * ------------------------------------------------------------------------- */
#include "stm32l552xx.h"
#include "lab3.h"
#include "evq.h"
#include "evq_test.h"
#include "acq.h"
#include "adc_dma.h"
#include "telem.h"
#include "fsm.h"
#include "bench_l3a.h"
#include "lab4.h"
#include "i2c.h"
#include "ioexp.h"
#include "lcd.h"
#include "touchpad.h"
#include "spi.h"
#include "env.h"
#include "tableau.h"
#include "somme_test.h"
#include "tableau_test.h"

/* tampon DMA : ADC_N_MOY échantillons par voie, entrelacés IN1, IN2, ... */
static volatile uint16_t tampon_adc[ADC_N_VOIES * ADC_N_MOY];
static acq_t acq_pot;      /* potentiomètre : 0..100 %                        */
static acq_t acq_temp;     /* température : dixièmes de degré Celsius         */
static ioexp_t x_del, x_commut;
static env_mesure_t env_courant;
static uint16_t tp_avant;
static uint8_t sw_stable = 0xFFu, sw_candidat = 0xFFu, sw_compte[8];
static uint32_t touches_refusees, ticks_perdus, dernier_tick;

static void commutateurs(uint8_t lu, uint32_t t)
{
    for (uint32_t i = 0u; i < 8u; i++) {
        uint8_t bit = (uint8_t)(1u << i);
        if ((lu & bit) != (sw_candidat & bit)) {
            sw_candidat ^= bit; sw_compte[i] = 1u;
        } else if (sw_compte[i] < COMMUT_ANTIREBOND_MS / COMMUT_PERIODE_MS) {
            sw_compte[i]++;
        }
        if (sw_compte[i] >= COMMUT_ANTIREBOND_MS / COMMUT_PERIODE_MS &&
            (sw_candidat & bit) != (sw_stable & bit)) {
            sw_stable ^= bit;
            if (!(sw_stable & bit)) evq_push(EV_COMMUT, i + 1u, t);
        }
    }
}

volatile uint32_t compteur_pas;          /* passages dans la boucle (watch)    */

void SystemInit(void)
{
    /* horloge MSI 4 MHz de la réinitialisation : rien à faire (HORLOGE_HZ_C) */
}

static void dwt_init(void)
{
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT = 0u;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
}

static void reponse_u32(const char *etiquette, uint32_t v)
{
    char ligne[48];
    char *p = ligne;
    while (*etiquette) *p++ = *etiquette++;
    p = telem_fmt_u32(p, v);
    *p++ = '\r'; *p++ = '\n'; *p = '\0';
    telem_put(ligne);
}

int main(void)
{
    uint32_t fenetre = 0u, periode_telem = 0u, perio_sw = 0u;
    uint8_t scan[8];
    uint32_t n_scan;
    uint32_t pir_niveau = 0u, defaut_signale = 0u;
    int32_t  derniere_consigne = -1;
    evq_event_t e;

    /* couche assembleur (sorties en état sûr avant les interruptions) */
    gpio_init();
    buzzer_init();
    motor_init();
    encoder_init();
    estop_init();
    systick_init(1000u);
    /* couche C */
    dwt_init();
    evq_init();
    adc_dma_init(tampon_adc, ADC_N_MOY);
    /* potentiomètre : % = mv x 100 / 3300 ; version 2 : zone morte 3 %, hystérésis 2 */
    acq_init(&acq_pot, &tampon_adc[0], ADC_N_VOIES, ADC_N_MOY, 100, (int32_t)ADC_VREF_MV, 0);
    acq_config_filtre(&acq_pot, CONSIGNE_HYSTERESIS, POT_ZONE_MORTE_PCT, 0, 100);
    /* température : t10 = (mv - MV_REF) x (-10900) / 1000 ... en dixièmes :
     * t10 = mv x (-10000) / 10900 + (C10_REF + MV_REF x 10000 / 10900)        */
    acq_init(&acq_temp, &tampon_adc[1], ADC_N_VOIES, ADC_N_MOY,
             -10000, -TEMP_PENTE_UV_PAR_C,
             TEMP_C10_REF + (TEMP_MV_REF * 10000) / (-TEMP_PENTE_UV_PAR_C));
    telem_init(TELEM_BAUDS);
    fsm_init();
    telem_entete();
    i2c_init();
    spi_init();
    exti_l4_init();
    n_scan = i2c_scan(scan, 8u);
    telem_scan(scan, n_scan);
    ioexp_init(&x_del, I2C_ADR_DEL);
    ioexp_init(&x_commut, I2C_ADR_COMMUT);
    (void)ioexp_ecrire(&x_commut, 0xFFu);
    (void)tp_init();
    lcd_init();
    tableau_init();
    (void)env_init();
    dernier_tick = ticks_ms;

    for (;;) {
        if (tick_1ms == 0u) {
            continue;                                   /* attente du tick    */
        }
        tick_1ms = 0u;
        compteur_pas++;
        uint32_t t = ticks_ms;
        if ((uint32_t)(t - dernier_tick) > 1u) ticks_perdus += t - dernier_tick - 1u;
        dernier_tick = t;

        /* --- producteurs d'événements --- */
        if (button_pressed(BTN_USER))  { evq_push(EV_USER, 0u, t); }
        if (button_pressed(BTN_TOUCH)) { evq_push(EV_TOUCH, 0u, t); }
        if (estop_flag) {
            estop_flag = 0u;
            motor_stop_now();                           /* redondant avec l'ISR */
            evq_push(EV_ESTOP, 0u, t);
        }
        if (pir_flag) {
            pir_flag = 0u;
            pir_niveau = 1u;
            evq_push(EV_PIR, 1u, pir_t_ms);
        }
        if (!(GPIOB->IDR & GPIO_IDR_ID9) && pir_niveau) {
            pir_niveau = 0u;
            evq_push(EV_PIR, 0u, t);
        }
        if (++fenetre >= FENETRE_VITESSE_MS) {
            fenetre = 0u;
            uint32_t fronts = encoder_read(&sens_mesure);
            evq_push(EV_VITESSE, fronts, t);
        }
        int32_t c = acq_valeur(&acq_pot);
        if (c != derniere_consigne) {
            derniere_consigne = c;
            evq_push(EV_CONSIGNE, (uint32_t)c, t);
        }
        if (++periode_telem >= TELEM_PERIODE_MS) {
            periode_telem = 0u;
            evq_push(EV_TELEM, 0u, t);
        }
        adc_dma_step();

        /* Un arbitrage unique par milliseconde: TouchPad > commutateurs >
         * DEL > LCD (le RVB est gere dans lcd_step). Aucun bus en ISR. */
        tableau_step();
        if (thi_flag) {
            thi_flag = 0u;
            uint16_t tp_apres;
            if (tp_lire(&tp_apres)) {
                int32_t touche = tp_touche(tp_avant, tp_apres);
                tp_avant = tp_apres;
                if (touche >= 0) {
                    if (touch_enabled) evq_push(EV_TOUCHE, (uint32_t)touche, t);
                    else { touches_refusees++; tableau_verrou(); }
                }
            }
        } else if (++perio_sw >= COMMUT_PERIODE_MS) {
            perio_sw = 0u;
            uint8_t lu;
            if (ioexp_lire(&x_commut, &lu)) commutateurs(lu, t);
        } else if (!x_del.sortie_connue || x_del.sortie != (uint8_t)~tableau_image_del()) {
            (void)ioexp_ecrire(&x_del, (uint8_t)~tableau_image_del());
        } else lcd_step();
        env_step();
        env_mesure_t nouvelle_env;
        if (env_mesure(&nouvelle_env)) {
            env_courant = nouvelle_env;
            evq_push(EV_ENV, nouvelle_env.h_x10, t);
        }
        env_courant.ta_c10 = acq_valeur(&acq_temp);
        tableau_env(&env_courant);
        uint32_t defaut_present = lcd_echecs() >= I2C_ERREURS_DEFAUT ||
                                  x_commut.echecs >= I2C_ERREURS_DEFAUT ||
                                  x_del.echecs >= I2C_ERREURS_DEFAUT;
        if (defaut_present != defaut_signale) {
            defaut_signale = defaut_present;
            evq_push(EV_DEFAUT, defaut_present ? I2C_ADR_LCD : 0u, t);
        }

        /* --- commandes série facultatives --- */
        int rx = telem_rx();
        if (rx == 'z') {
            evq_init();
            derniere_consigne = -1;
            telem_put("Z,ok\r\n");
        } else if (rx == 't') {
            for (uint32_t i = 0u; i < 40u; i++) { evq_push(EV_TEST, i, t); }
        } else if (rx == 'q') {
            reponse_u32("Q,echecs=", evq_autotest());
        } else if (rx == 'b') {
            if (etat == ETAT_ARRET) {
                reponse_u32("B,ecarts=", bench_l3a());
                reponse_u32("B,cycles_asm=", bench_cycles_asm);
                reponse_u32("B,cycles_c=", bench_cycles_c);
            } else {
                telem_put("B,refuse (ARRET requis)\r\n");
            }
        } else if (rx == 'a') {
            reponse_u32("A,pot_brut=", acq_brut(&acq_pot));
            reponse_u32("A,pot_mv=", acq_mv(&acq_pot));
            reponse_u32("A,temp_brut=", acq_brut(&acq_temp));
            reponse_u32("A,temp_mv=", acq_mv(&acq_temp));
            reponse_u32("A,tours_dma=", adc_dma_tours());
        } else if (rx == 'x') {
            reponse_u32("X,echecs=", somme_autotest());
        } else if (rx == 'f') {
            reponse_u32("F,echecs=", tableau_autotest());
        } else if (rx == 'i') {
            n_scan = i2c_scan(scan, 8u);
            telem_scan(scan, n_scan);
        } else if (rx == 'd') {
            i2c_simuler_absence(I2C_ADR_LCD, ABSENCE_SIMULEE_MS);
            lcd_init(); /* force des ecritures pour constater le NACK */
        }

        /* --- consommateur : machine à états --- */
        while (evq_pop(&e)) {
            if (e.type == EV_TELEM) {
                telem_trame(fsm_etat(), acq_valeur(&acq_temp), evq_total(),
                            evq_debordements(), &env_courant, i2c_erreurs(), ticks_perdus);
            } else {
                if (e.type == EV_COMMUT && e.valeur == SW_PAGE) tableau_page_basculer();
                fsm_traiter(&e);
                if (e.type == EV_PIR || e.type == EV_TOUCHE || e.type == EV_COMMUT ||
                    e.type == EV_ESTOP || e.type == EV_DEFAUT) telem_evenement(&e);
            }
        }
        fsm_sorties();
        telem_step();
    }
}
