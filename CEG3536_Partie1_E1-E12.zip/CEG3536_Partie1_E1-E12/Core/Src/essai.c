/* ---------------------------------------------------------------------------
 * essai.c — mode essai : injection de valeurs de capteurs
 *           (CEG 3536, projet final, E20) — SQUELETTE À COMPLÉTER
 * Module sans matériel, testé sur hôte : make surv dans hote/.
 * La bascule du mode (commande m) est fournie ; les injections sont à écrire.
 * ------------------------------------------------------------------------- */
#include "essai.h"

static bool actif;              /* mode essai actif                          */
static bool inj_temp, inj_hum, inj_sens, inj_fronts;
static int32_t temp_injectee;
static uint32_t hum_injectee;

static void annuler_injections(void)
{
    inj_temp = inj_hum = inj_sens = inj_fronts = false;
}

void essai_init(void)
{
    actif = false;
    annuler_injections();
}

bool essai_actif(void)
{
    return actif;
}

void essai_basculer(void)
{
    actif = !actif;
    if (!actif) {
        annuler_injections();           /* retour aux mesures réelles        */
    }
}

bool essai_commande(char c)
{
    if (c == 'm') {
        essai_basculer();
        return true;
    }
    if (!actif) {
        return false;                   /* injections refusées hors du mode  */
    }
    switch (c) {
    case '1': inj_temp = true; temp_injectee = ESSAI_TEMP_1_C10; return true;
    case '2': inj_temp = true; temp_injectee = ESSAI_TEMP_2_C10; return true;
    case '3': inj_temp = true; temp_injectee = ESSAI_TEMP_3_C10; return true;
    case 'h': hum_injectee = (!inj_hum || hum_injectee == ESSAI_HUM_BASSE_X10)
                               ? ESSAI_HUM_HAUTE_X10 : ESSAI_HUM_BASSE_X10;
              inj_hum = true; return true;
    case 's': inj_sens = !inj_sens; return true;
    case 'n': inj_fronts = !inj_fronts; return true;
    default: return false;
    }
}

int32_t essai_temp_c10(int32_t mesure)
{
    return actif && inj_temp ? temp_injectee : mesure;
}

uint32_t essai_hum_x10(uint32_t mesure)
{
    return actif && inj_hum ? hum_injectee : mesure;
}

uint32_t essai_sens(uint32_t mesure)
{
    if (actif && inj_sens) {
        if (mesure == SENS_AVANT) return SENS_ARRIERE;
        if (mesure == SENS_ARRIERE) return SENS_AVANT;
    }
    return mesure;
}

uint32_t essai_fronts(uint32_t mesure)
{
    return actif && inj_fronts ? 0u : mesure;
}
