/* ---------------------------------------------------------------------------
 * trajet.c — suivi d'un trajet défini en distance
 *            (CEG 3536, projet final, E16) — SQUELETTE À COMPLÉTER
 * Module sans matériel, testé sur hôte : make trajet dans hote/.
 *
 * Indications :
 *  - conserver la distance en FRONTS (entier de 32 bits : 105 tours valent
 *    78 540 fronts), et n'en déduire les dixièmes de tour qu'à l'affichage :
 *    dist_x10 = fronts x 10 / 748 ;
 *  - calculer une fois, dans trajet_init, la distance totale et, si l'on
 *    veut, la borne de fin de chaque segment en fronts ;
 *  - le segment courant est le premier dont la borne de fin dépasse la
 *    distance parcourue ; aucune notion de temps n'intervient.
 * ------------------------------------------------------------------------- */
#include "trajet.h"

/* Trajet de référence de l'énoncé (section 4.8) : 105 tours — FOURNI        */
const segment_t TRAJET_REF[TRAJET_REF_N] = {
    { 20u, 150u },      /* S1 : démarrage et établissement de la vitesse     */
    { 40u, 250u },      /* S2 : accélération ; arrêt au feu rouge et reprise  */
    { 15u, 100u },      /* S3 : ralentissement marqué                        */
    { 30u, 200u },      /* S4 : nouvelle accélération, puis fin de trajet    */
};

static const segment_t *segments;   /* trajet courant                        */
static uint32_t nb_segments;
static uint32_t distance_fronts, total_fronts, segment_courant;

void trajet_init(const segment_t *s, uint32_t n)
{
    segments = s;
    nb_segments = n;
    total_fronts = 0u;
    for (uint32_t i = 0u; i < n; i++) {
        total_fronts += (uint32_t)s[i].tours * FRONTS_PAR_TOUR;
    }
    trajet_reset();
}

void trajet_reset(void)
{
    distance_fronts = 0u;
    segment_courant = nb_segments ? 1u : 0u;
}

void trajet_avancer(uint32_t fronts)
{
    if (fronts >= total_fronts - distance_fronts) distance_fronts = total_fronts;
    else distance_fronts += fronts;
    uint32_t borne = 0u;
    for (uint32_t i = 0u; i < nb_segments; i++) {
        borne += (uint32_t)segments[i].tours * FRONTS_PAR_TOUR;
        if (distance_fronts < borne) { segment_courant = i + 1u; return; }
    }
    segment_courant = nb_segments;
}

uint32_t trajet_consigne_rpm(void)
{
    return (segment_courant && !trajet_fini()) ? segments[segment_courant - 1u].consigne_rpm : 0u;
}

uint32_t trajet_segment(void)
{
    return segment_courant;
}

uint32_t trajet_nb_segments(void)
{
    return nb_segments;
}

uint32_t trajet_dist_x10(void)
{
    return (uint32_t)(((uint64_t)distance_fronts * 10u) / FRONTS_PAR_TOUR);
}

uint32_t trajet_total_tours(void)
{
    return total_fronts / FRONTS_PAR_TOUR;
}

bool trajet_fini(void)
{
    return distance_fronts >= total_fronts;
}
