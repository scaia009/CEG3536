/* ---------------------------------------------------------------------------
 * telem.c — télémétrie LPUART1 au niveau des registres (CMSIS, sans HAL)
 *           (CEG 3536, laboratoire 3) — CORRIGÉ
 *
 * LPUART1 : TX = PG7, RX = PG8 (AF8), 115 200 bauds, 8N1, vers le port COM
 * virtuel du ST-LINK (guide, p. 54-55). Le port G (broches 2 à 15) est alimenté
 * par VDDIO2 : PWR_CR2.IOSV doit être mis à 1 (RM0438, section PWR).
 * Horloge noyau = PCLK1 = 4 MHz (RCC_CCIPR1.LPUART1SEL = 00) :
 *   BRR = 256 x 4 000 000 / 115 200 = 8 889 (fck >= 3 x bauds : respecté).
 * FIFO activée (8 octets) : telem_step remplit la FIFO à chaque tick sans
 * attendre ; une trame de 60 caractères toutes les 200 ms occupe ~ 2,5 % de la
 * capacité de la liaison (11,5 ko/s).
 * ------------------------------------------------------------------------- */
#include "stm32l552xx.h"
#include "telem.h"
#include "lab4.h"
#include "projet.h"
#include "i2c.h"
#include "evq.h"
#include "crit_test.h"
#include "essai.h"

#define TX_TAILLE 2048u
static char     tx_file[TX_TAILLE];
static uint32_t tx_tete, tx_queue, tx_nombre, pertes;

void telem_init(uint32_t bauds)
{
    RCC->APB1ENR1 |= RCC_APB1ENR1_PWREN;
    (void)RCC->APB1ENR1;
    PWR->CR2 |= PWR_CR2_IOSV;                         /* alimentation du port G */
    RCC->AHB2ENR |= RCC_AHB2ENR_GPIOGEN;
    RCC->APB1ENR2 |= RCC_APB1ENR2_LPUART1EN;
    RCC->CCIPR1 &= ~RCC_CCIPR1_LPUART1SEL;            /* 00 = PCLK1             */
    (void)RCC->APB1ENR2;

    /* PG7 (TX) : AFRL champ 7 = 8 ; PG8 (RX) : AFRH champ 0 = 8 ; MODER = 10 */
    GPIOG->AFR[0] = (GPIOG->AFR[0] & ~GPIO_AFRL_AFSEL7) | (8u << GPIO_AFRL_AFSEL7_Pos);
    GPIOG->AFR[1] = (GPIOG->AFR[1] & ~GPIO_AFRH_AFSEL8) | (8u << GPIO_AFRH_AFSEL8_Pos);
    GPIOG->MODER = (GPIOG->MODER & ~(GPIO_MODER_MODE7 | GPIO_MODER_MODE8))
                 | GPIO_MODER_MODE7_1 | GPIO_MODER_MODE8_1;
    GPIOG->OSPEEDR |= GPIO_OSPEEDR_OSPEED7_0;         /* vitesse moyenne        */
    GPIOG->PUPDR = (GPIOG->PUPDR & ~GPIO_PUPDR_PUPD8) | GPIO_PUPDR_PUPD8_0; /* RX tiré à 1 */

    LPUART1->CR1 = 0u;
    LPUART1->BRR = (256u * HORLOGE_HZ_C + bauds / 2u) / bauds;   /* 8 889 */
    LPUART1->CR2 = 0u;
    LPUART1->CR3 = 0u;
    LPUART1->CR1 = USART_CR1_FIFOEN | USART_CR1_TE | USART_CR1_RE;
    LPUART1->CR1 |= USART_CR1_UE;

    tx_tete = tx_queue = tx_nombre = pertes = 0u;
}

bool telem_put(const char *s)
{
    uint32_t taille = 0u;
    while (s[taille]) taille++;
    if (taille > TX_TAILLE - tx_nombre) { pertes++; return false; }
    while (*s) {
        tx_file[tx_queue] = *s++;
        tx_queue = (tx_queue + 1u) % TX_TAILLE;
        tx_nombre++;
    }
    return true;
}

void telem_step(void)
{
    /* remplit la FIFO matérielle (8 octets) tant qu'elle n'est pas pleine */
    while (tx_nombre > 0u && (LPUART1->ISR & USART_ISR_TXE_TXFNF)) {
        LPUART1->TDR = (uint8_t)tx_file[tx_tete];
        tx_tete = (tx_tete + 1u) % TX_TAILLE;
        tx_nombre--;
    }
}

int telem_rx(void)
{
    if (LPUART1->ISR & USART_ISR_RXNE_RXFNE) {
        return (int)(LPUART1->RDR & 0xFFu);
    }
    if (LPUART1->ISR & USART_ISR_ORE) {               /* débordement : effacer */
        LPUART1->ICR = USART_ICR_ORECF;
    }
    return -1;
}

uint32_t telem_pertes(void) { return pertes; }

/* ---- formatage entier ------------------------------------------------- */
char *telem_fmt_u32(char *p, uint32_t v)
{
    char tmp[11];
    int n = 0;
    do { tmp[n++] = (char)('0' + v % 10u); v /= 10u; } while (v);
    while (n) *p++ = tmp[--n];
    *p = '\0';
    return p;
}

char *telem_fmt_i32(char *p, int32_t v)
{
    if (v < 0) { *p++ = '-'; v = -v; }
    return telem_fmt_u32(p, (uint32_t)v);
}

/* ---- trames ------------------------------------------------------------ */
void telem_entete(void)
{
    telem_put("H,ticks_ms,etat,sens,consigne_pct,pwm_pct,temp_c_x10,vitesse_rpm_x100,nb_evenements,evq_debordements,mode,cause,plafond_pct,env_t_x10,env_h_x10,env_p_x10,i2c_erreurs,ticks_perdus"
#if CEG_PARTIE_II
              ",mode_essai,segment,dist_x10,consigne_rpm,code_defaut,evq_max,crit_max_cycles"
#endif
              "\r\n");
}

static char *champ_u(char *p, uint32_t v) { *p++ = ','; return telem_fmt_u32(p, v); }
static char *champ_i(char *p, int32_t v) { *p++ = ','; return telem_fmt_i32(p, v); }
static void envoyer_xor(char *debut, char *p)
{
    const char hexa[] = "0123456789ABCDEF";
    uint8_t x = (uint8_t)trame_xor8((const uint8_t *)debut, (uint32_t)(p - debut));
    *p++ = '*'; *p++ = hexa[x >> 4]; *p++ = hexa[x & 0x0Fu];
    *p++ = '\r'; *p++ = '\n'; *p = '\0';
    telem_put(debut);
}

void telem_trame(const etat_vehicule_t *v, int32_t temp_c_x10,
                 uint32_t nb_evenements, uint32_t debordements,
                 const env_mesure_t *env, uint32_t erreurs_i2c,
                 uint32_t ticks_perdus)
{
    char ligne[256];
    char *p = ligne;
    uint32_t rpm_x100 = (uint32_t)(((uint64_t)v->vitesse_rpm_q16 * 100u + 32768u) >> 16);

    *p++ = 'T';
    p = champ_u(p, ticks_ms);
    p = champ_u(p, v->etat);
    p = champ_u(p, v->sens);
    p = champ_u(p, v->consigne_pct);
    p = champ_u(p, v->pwm_pct);
    p = champ_i(p, temp_c_x10);
    p = champ_u(p, rpm_x100);
    p = champ_u(p, nb_evenements);
    p = champ_u(p, debordements);
    p = champ_u(p, v->mode);
    p = champ_u(p, v->cause);
    p = champ_u(p, v->plafond_pct);
    p = champ_i(p, env && env->valide ? env->t_c10 : 0);
    p = champ_u(p, env && env->valide ? env->h_x10 : 0u);
    p = champ_u(p, env && env->valide ? env->p_hpa_x10 : 0u);
    p = champ_u(p, erreurs_i2c);
    p = champ_u(p, ticks_perdus);
#if CEG_PARTIE_II
    p = champ_u(p, v->mode_essai);
    p = champ_u(p, v->segment);
    p = champ_u(p, v->dist_x10);
    p = champ_u(p, v->consigne_rpm);
    p = champ_u(p, v->code_defaut);
    p = champ_u(p, evq_max());
    p = champ_u(p, crit_max_cycles);
#endif
    envoyer_xor(ligne, p);
}

void telem_evenement(const evq_event_t *e)
{
    char ligne[80], *p = ligne;
    *p++ = 'E';
    p = champ_u(p, e->t_ms);
    p = champ_u(p, (uint32_t)e->type);
    p = champ_u(p, e->valeur);
    envoyer_xor(ligne, p);
}

void telem_scan(const uint8_t *adresses, uint32_t n)
{
    const char hexa[] = "0123456789ABCDEF";
    char ligne[80], *p = ligne;
    *p++ = 'I'; p = champ_u(p, n);
    for (uint32_t i = 0u; i < n && i < 8u; i++) {
        *p++ = ','; *p++ = hexa[adresses[i] >> 4]; *p++ = hexa[adresses[i] & 0x0Fu];
    }
    envoyer_xor(ligne, p);
}
