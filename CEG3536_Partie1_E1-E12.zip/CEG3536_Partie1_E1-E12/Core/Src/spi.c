/* ---------------------------------------------------------------------------
 * spi.c — pilote SPI1 maître au niveau des registres (CMSIS, sans HAL)
 *         (CEG 3536, laboratoire 4, E7) — SQUELETTE À COMPLÉTER
 *
 * Séquence (RM0438, section SPI ; énoncé 4.7) :
 *   1. horloges : RCC_AHB2ENR (GPIOAEN, GPIODEN), RCC_APB2ENR (SPI1EN) ;
 *   2. PA5, PA6, PA7 : MODER = 10, AFRL champs 5, 6 et 7 = 5 (AF5) ;
 *      PD14 : niveau haut (BSRR) PUIS sortie (MODER = 01), pour ne jamais
 *      sélectionner le capteur par accident ;
 *   3. CR1 = MSTR | SSM | SSI | BR = 001 (PCLK2 / 4 = 1 MHz), CPOL = CPHA = 0 ;
 *   4. CR2 = DS = 0111 (8 bits) | FRXTH (RXNE dès un octet reçu) ;
 *   5. CR1 |= SPE.
 * Échange d'un octet : attendre SR.TXE, écrire l'octet dans DR par un accès de
 * 8 bits (*(volatile uint8_t *)&SPI1->DR), attendre SR.RXNE, lire DR de la
 * même façon. PD14 passe à 0 avant le premier octet et revient à 1 après le
 * dernier, une fois SR.BSY retombé.
 * Attentes : bornées (compteur de boucle ou ticks_ms) — un SPI mal configuré
 * ne doit pas bloquer la boucle principale.
 * Vérification au débogueur : SPI1->CR1, CR2, SR ; GPIOD->ODR bit 14 ; octet
 * reçu en lisant l'identifiant du capteur (env.c).
 * ------------------------------------------------------------------------- */
#include "stm32l552xx.h"
#include "lab4.h"
#include "spi.h"

void spi_init(void)
{
    RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN | RCC_AHB2ENR_GPIODEN;
    RCC->APB2ENR |= RCC_APB2ENR_SPI1EN;
    (void)RCC->APB2ENR;
    for (uint32_t p = 5u; p <= 7u; p++) {
        GPIOA->MODER = (GPIOA->MODER & ~(3u << (2u * p))) | (2u << (2u * p));
        GPIOA->AFR[0] = (GPIOA->AFR[0] & ~(15u << (4u * p))) | (5u << (4u * p));
    }
    GPIOD->BSRR = (1u << 14);
    GPIOD->MODER = (GPIOD->MODER & ~(3u << 28)) | (1u << 28);
    SPI1->CR1 = 0u;
    SPI1->CR2 = (7u << SPI_CR2_DS_Pos) | SPI_CR2_FRXTH;
    SPI1->CR1 = SPI_CR1_MSTR | SPI_CR1_SSM | SPI_CR1_SSI | (1u << SPI_CR1_BR_Pos);
    SPI1->CR1 |= SPI_CR1_SPE;
}

void spi_echange(const uint8_t *emis, uint8_t *recus, uint32_t n)
{
    if (n == 0u) return;
    GPIOD->BSRR = 1u << (14u + 16u);
    for (uint32_t i = 0u; i < n; i++) {
        uint32_t garde = 120000u;
        while (!(SPI1->SR & SPI_SR_TXE) && garde) garde--;
        if (!garde) break;
        *(volatile uint8_t *)&SPI1->DR = emis ? emis[i] : 0u;
        garde = 120000u;
        while (!(SPI1->SR & SPI_SR_RXNE) && garde) garde--;
        if (!garde) break;
        uint8_t r = *(volatile uint8_t *)&SPI1->DR;
        if (recus) recus[i] = r;
    }
    uint32_t garde = 120000u;
    while ((SPI1->SR & SPI_SR_BSY) && garde) garde--;
    GPIOD->BSRR = (1u << 14u);
}
