/* ---------------------------------------------------------------------------
 * env.c — capteur environnemental (CEG 3536, laboratoire 4, E7)
 *         — SQUELETTE À COMPLÉTER
 *
 * Repères (énoncé, 4.7 ; capteur BME680, À CONFIRMER dans la fiche technique
 * liée en annexe D du guide) :
 *   - premier octet d'un échange : bit 7 = 1 pour une lecture, 0 pour une
 *     écriture ; les 7 autres bits sont l'adresse du registre dans la page ;
 *   - deux pages, choisies par spi_mem_page (bit 4 du registre 0x73, accessible
 *     dans les deux pages) : page 0 = registres 0x80 à 0xFF, page 1 = registres
 *     0x00 à 0x7F. Changer de page seulement quand c'est nécessaire ;
 *   - identifiant : registre 0xD0 (page 0), valeur attendue 0x61 ;
 *   - coefficients : 25 octets à partir de 0x89 puis 16 octets à partir de
 *     0xE1 (page 0), à ranger dans cet ordre dans un tableau de 41 octets et à
 *     passer à bme680_coef_decoder ;
 *   - mesure forcée, sans capteur de gaz (page 1) : ctrl_hum (0x72) <- 0x01,
 *     ctrl_meas (0x74) <- 0x25 ; attendre que le bit new_data (bit 7) de 0x1D
 *     soit à 1 — quelques millisecondes, comptées en ticks, jamais en boucle
 *     d'attente ; lire en un seul échange les 8 registres 0x1F à 0x26 ;
 *   - conversion : bme680_brut_decoder puis bme680_temperature_c100 (d'abord :
 *     elle calcule t_fine), bme680_pression_pa, bme680_humidite_x1000 ; mettre
 *     à l'échelle de env_mesure_t (0,1 °C ; 0,1 % ; 0,1 hPa).
 * Une lecture de n registres est un échange de n + 1 octets : le premier
 * octet reçu est sans signification.
 * ------------------------------------------------------------------------- */
#include "lab4.h"
#include "spi.h"
#include "bme680_comp.h"
#include "env.h"

#define ENV_ID_ATTENDU      0x61u
#define ENV_ATTENTE_MAX_MS  50u     /* au-delà, la mesure est abandonnée       */

typedef enum {
    ENV_ABSENT,         /* identifiant incorrect : plus aucun échange          */
    ENV_REPOS,          /* attend la prochaine période                         */
    ENV_CONVERSION      /* mesure lancée, attend new_data                      */
} env_phase_t;

static env_phase_t   phase = ENV_ABSENT;
static bme680_coef_t coef;
static env_mesure_t  derniere;
static uint32_t      nouvelle, nb_mesures, t_phase;
static uint8_t       identifiant;
static uint8_t       page = 0xFFu;

static void page_choisir(uint8_t p)
{
    if (p == page) return;
    uint8_t d[2] = { 0x73u, p ? 0x10u : 0x00u };
    spi_echange(d, 0, 2u);
    page = p;
}

static void reg_ecrire(uint8_t adr, uint8_t valeur)
{
    page_choisir(adr < 0x80u ? 1u : 0u);
    uint8_t d[2] = { (uint8_t)(adr & 0x7Fu), valeur };
    spi_echange(d, 0, 2u);
}

static void reg_lire(uint8_t adr, uint8_t *data, uint32_t n)
{
    page_choisir(adr < 0x80u ? 1u : 0u);
    uint8_t tx[BME680_N_COEF + 1u] = { 0u };
    uint8_t rx[BME680_N_COEF + 1u] = { 0u };
    if (n > BME680_N_COEF) return;
    tx[0] = (uint8_t)((adr & 0x7Fu) | 0x80u);
    spi_echange(tx, rx, n + 1u);
    for (uint32_t i = 0u; i < n; i++) data[i] = rx[i + 1u];
}

bool env_init(void)
{
    derniere.valide = 0u;
    nouvelle = nb_mesures = 0u;
    identifiant = 0u;
    phase = ENV_ABSENT;
    uint8_t valeurs[BME680_N_COEF];
    page = 0xFFu;
    reg_lire(0xD0u, &identifiant, 1u);
    if (identifiant != ENV_ID_ATTENDU) return false;
    reg_lire(0x89u, valeurs, 25u);
    reg_lire(0xE1u, valeurs + 25u, 16u);
    bme680_coef_decoder(valeurs, &coef);
    phase = ENV_REPOS;
    t_phase = ticks_ms;
    return identifiant == ENV_ID_ATTENDU;
}

void env_step(void)
{
    if (phase == ENV_REPOS && (uint32_t)(ticks_ms - t_phase) >= ENV_PERIODE_MS) {
        reg_ecrire(0x72u, 0x01u);
        reg_ecrire(0x74u, 0x25u);
        t_phase = ticks_ms;
        phase = ENV_CONVERSION;
    } else if (phase == ENV_CONVERSION) {
        uint8_t statut;
        reg_lire(0x1Du, &statut, 1u);
        if (statut & 0x80u) {
            uint8_t brut[BME680_N_BRUT];
            uint32_t p, t, h;
            reg_lire(0x1Fu, brut, BME680_N_BRUT);
            bme680_brut_decoder(brut, &p, &t, &h);
            int32_t t100 = bme680_temperature_c100(&coef, t);
            derniere.t_c10 = t100 / 10;
            derniere.p_hpa_x10 = bme680_pression_pa(&coef, p) / 10u;
            derniere.h_x10 = bme680_humidite_x1000(&coef, h) / 100u;
            derniere.valide = 1u;
            nouvelle = 1u; nb_mesures++;
            t_phase = ticks_ms; phase = ENV_REPOS;
        } else if ((uint32_t)(ticks_ms - t_phase) > ENV_ATTENTE_MAX_MS) {
            phase = ENV_REPOS; t_phase = ticks_ms;
        }
    }
}

/* [FOURNI] */
bool env_mesure(env_mesure_t *m)
{
    if (!nouvelle) {
        return false;
    }
    nouvelle = 0u;
    m->t_c10 = derniere.t_c10;
    m->h_x10 = derniere.h_x10;
    m->p_hpa_x10 = derniere.p_hpa_x10;
    m->valide = derniere.valide;
    return true;
}

uint8_t  env_identifiant(void) { return identifiant; }
uint32_t env_nb_mesures(void)  { return nb_mesures; }
