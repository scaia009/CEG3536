/* ---------------------------------------------------------------------------
 * tableau.c — formatage du tableau de bord (CEG 3536, laboratoire 4, E3, E8)
 *             — SQUELETTE À COMPLÉTER
 * AUCUN accès matériel, aucun en-tête CMSIS, pas de printf : ce fichier est
 * compilé tel quel sur la cible et sur hôte (hote/test_tableau.c, E11).
 * Les formats sont définis dans tableau.h ; l'autotest (tableau_test.c) en
 * vérifie six cas — les faire passer sur hôte AVANT de brancher l'afficheur.
 * ------------------------------------------------------------------------- */
#include "tableau.h"
#include "projet.h"

/* [FOURNI] remplit une ligne de 16 espaces, terminée par '\0' */
static void ligne_vide(char l[17])
{
    for (uint32_t i = 0u; i < 16u; i++) {
        l[i] = ' ';
    }
    l[16] = '\0';
}

/* [FOURNI] copie s dans l à partir de la colonne col, sans dépasser 16 ni
 * écrire le '\0' de s ; retourne la colonne qui suit                          */
static uint32_t placer(char l[17], uint32_t col, const char *s)
{
    while (*s != '\0' && col < 16u) {
        l[col++] = *s++;
    }
    return col;
}

/* Écrit x10 / 10 avec une décimale, cadré à droite sur largeur caractères, à
 * partir de la colonne col ; retourne la colonne qui suit.
 * Exemples (largeur 6) : 2453 -> " 245.3" ; 0 -> "   0.0" ; -52 -> "  -5.2".
 * À COMPLÉTER (chiffres produits de droite à gauche ; signe ; espaces).       */
static uint32_t placer_fixe1(char l[17], uint32_t col, int32_t x10, uint32_t largeur)
{
    char tampon[16];
    uint32_t n = 0u;
    uint32_t abs_x = x10 < 0 ? (uint32_t)(-(int64_t)x10) : (uint32_t)x10;
    tampon[n++] = (char)('0' + abs_x % 10u);
    tampon[n++] = '.';
    abs_x /= 10u;
    do { tampon[n++] = (char)('0' + abs_x % 10u); abs_x /= 10u; } while (abs_x && n < 14u);
    if (x10 < 0) tampon[n++] = '-';
    for (uint32_t i = 0u; i < largeur; i++) {
        if (col + i < 16u) l[col + i] = i < largeur - n ? ' ' : tampon[largeur - i - 1u];
    }
    return col + largeur;
}

static void placer_3(char l[17], uint32_t col, uint32_t v)
{
    if (v > 999u) v = 999u;
    l[col] = (char)('0' + v / 100u);
    l[col + 1u] = (char)('0' + (v / 10u) % 10u);
    l[col + 2u] = (char)('0' + v % 10u);
}

void tableau_formater(const etat_vehicule_t *v, const env_mesure_t *m,
                      uint32_t page, char l1[17], char l2[17])
{
    ligne_vide(l1);
    ligne_vide(l2);

    if (page == PAGE_CAPTEURS) {
        placer(l1, 0u, "T"); placer(l1, 6u, "C  H"); placer(l1, 15u, "%");
        placer(l2, 0u, "P"); placer(l2, 7u, "hPa A");
        if (m->valide) {
            placer_fixe1(l1, 1u, m->t_c10, 5u);
            placer_fixe1(l1, 10u, (int32_t)m->h_x10, 5u);
            placer_fixe1(l2, 1u, (int32_t)m->p_hpa_x10, 6u);
        } else {
            placer(l1, 1u, " --.-"); placer(l1, 10u, " --.-");
            placer(l2, 1u, " ---.-");
        }
        placer_fixe1(l2, 12u, m->ta_c10, 4u);
    } else if (page == PAGE_TRAJET) {
        placer(l1, 0u, "S"); l1[1] = (char)('0' + (v->segment % 10u));
        l1[2] = '/'; l1[3] = (char)('0' + TRAJET_REF_N);
        placer(l1, 4u, " D ");
        placer_3(l1, 7u, v->dist_x10 / 10u);
        l1[10] = '.'; l1[11] = (char)('0' + (v->dist_x10 % 10u));
        l1[12] = '/'; placer_3(l1, 13u, 105u); /* total TRAJET_REF */
        if (v->mode == MODE_AUTONOME) {
            placer(l2, 0u, "R"); placer_3(l2, 1u, v->consigne_rpm);
            placer(l2, 4u, " V");
            uint32_t rpm10 = (uint32_t)(((uint64_t)v->vitesse_rpm_q16 * 10u + 32768u) >> 16);
            placer_fixe1(l2, 6u, (int32_t)rpm10, 5u);
            int32_t err = v->consigne_rpm ? ((int32_t)v->consigne_rpm - (int32_t)(rpm10 / 10u)) * 100 / (int32_t)v->consigne_rpm : 0;
            if (err > 99) err = 99;
            if (err < -99) err = -99;
            l2[12] = err < 0 ? '-' : '+';
            uint32_t a = (uint32_t)(err < 0 ? -err : err);
            l2[13] = (char)('0' + a / 10u); l2[14] = (char)('0' + a % 10u); l2[15] = '%';
        } else placer(l2, 0u, "R--- V  ---.- --%");
    } else {
        placer(l1, 0u, v->mode == MODE_AUTONOME ? "AUT" : "MAN");
        l1[3] = (v->drapeaux & DRAPEAU_ESSAI) ? '*' : ' ';
        placer(l1, 4u, v->etat == ETAT_MARCHE_AVANT ? "AV" :
                        v->etat == ETAT_MARCHE_ARRIERE ? "AR" : "--");
        const char *etat_str = "ARRET";
        switch (v->etat) {
        case ETAT_MARCHE_AVANT: case ETAT_MARCHE_ARRIERE: etat_str = "MARCHE"; break;
        case ETAT_ARRET_URGENCE: etat_str = "URGENCE"; break;
        case ETAT_ARRET_EVENEMENT:
            etat_str = v->cause == CAUSE_FEU ? "FEU ROUGE" : v->cause == CAUSE_THERMIQUE ? "THERMIQUE" :
                       v->cause == CAUSE_DEFAUT ? "DEFAUT" : "OBSTACLE"; break;
        case ETAT_DEFAUT: etat_str = "DEFAUT"; break;
        case ETAT_INIT: etat_str = "INIT"; break;
        default: if (v->cause == CAUSE_FIN) etat_str = "FIN"; break;
        }
        placer(l1, 7u, etat_str);
        if (page == PAGE_VERROU) { ligne_vide(l1); placer(l1, 0u, "VERROU"); }
        placer(l2, 0u, "C"); placer_3(l2, 1u, v->consigne_pct);
        placer(l2, 4u, "% V");
        uint32_t rpm10 = (uint32_t)(((uint64_t)v->vitesse_rpm_q16 * 10u + 32768u) >> 16);
        placer_fixe1(l2, 7u, (int32_t)rpm10, 6u);
        placer(l2, 13u, " P");
        l2[15] = v->plafond_pct >= 100u ? 'X' : (char)('0' + v->plafond_pct / 10u);
    }
}

uint8_t tableau_del(const etat_vehicule_t *v)
{
    uint8_t image = 0u;
    if (v->drapeaux & DRAPEAU_LIMITATION) image |= DEL_Y1;
    if (v->mode == MODE_AUTONOME) image |= DEL_Y2;
    if (v->drapeaux & DRAPEAU_TOUCH) image |= DEL_Y3;
    if (v->drapeaux & DRAPEAU_FIN) image |= DEL_Y4;
    if (v->drapeaux & DRAPEAU_FEU) image |= DEL_R1;
    if (v->drapeaux & DRAPEAU_OBSTACLE) image |= DEL_R2;
    if (v->drapeaux & (DRAPEAU_DEFAUT | DRAPEAU_THERMIQUE)) image |= DEL_R3;
    if (v->etat == ETAT_ARRET_URGENCE) image |= DEL_R4;
    return image;
}
