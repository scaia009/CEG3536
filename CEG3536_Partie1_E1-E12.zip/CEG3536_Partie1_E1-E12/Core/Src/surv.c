/* ---------------------------------------------------------------------------
 * surv.c — surveillances : sens, encodeur muet, protection thermique
 *          (CEG 3536, projet final, E18, E19) — SQUELETTE À COMPLÉTER
 * Module sans matériel, testé sur hôte : make surv dans hote/.
 *
 * Indications :
 *  - deux compteurs en millisecondes (sens opposé, encodeur muet), augmentés
 *    de dt_ms tant que la condition est vraie, remis à zéro sinon ;
 *  - « plus de 500 ms » : le défaut est levé quand le compteur DÉPASSE le
 *    délai, pas quand il l'atteint ;
 *  - deux comparateurs à hystérésis indépendants pour la température : chacun
 *    garde son état tant que la température est entre ses deux seuils.
 * ------------------------------------------------------------------------- */
#include "surv.h"

static uint32_t code;           /* DEFAUT_x mémorisé                         */
static uint32_t sens_ms, muet_ms, limite, arret;

void surv_init(void)
{
    code = DEFAUT_AUCUN;
    sens_ms = muet_ms = limite = arret = 0u;
}

void surv_step(const etat_vehicule_t *v, uint32_t sens_mesure, uint32_t fronts,
               int32_t temp_c10, uint32_t dt_ms)
{
    if (!limite && temp_c10 >= TEMP_LIMITE_C10) limite = 1u;
    if (limite && temp_c10 <= TEMP_LIMITE_FIN_C10) limite = 0u;
    if (!arret && temp_c10 >= TEMP_ARRET_C10) arret = 1u;
    if (arret && temp_c10 <= TEMP_ARRET_FIN_C10) arret = 0u;
    bool marche = v->etat == ETAT_MARCHE_AVANT || v->etat == ETAT_MARCHE_ARRIERE;
    bool oppose = marche && ((v->etat == ETAT_MARCHE_AVANT && sens_mesure == SENS_ARRIERE)
                           || (v->etat == ETAT_MARCHE_ARRIERE && sens_mesure == SENS_AVANT));
    if (oppose) sens_ms += dt_ms; else sens_ms = 0u;
    if (marche && v->pwm_pct > SURV_MUET_PWM_PCT && fronts == 0u) muet_ms += dt_ms;
    else muet_ms = 0u;
    if (code == DEFAUT_AUCUN) {
        if (sens_ms > SURV_SENS_MS) code = DEFAUT_SENS;
        else if (muet_ms > SURV_MUET_MS) code = DEFAUT_ENCODEUR;
    }
}

uint32_t surv_code(void)
{
    return code;
}

void surv_acquitter(void)
{
    code = DEFAUT_AUCUN;
    sens_ms = muet_ms = 0u;
}

uint32_t surv_thermique(void)
{
    return arret ? SURV_THERM_ARRET : (limite ? SURV_THERM_LIMITATION : SURV_THERM_NORMAL);
}
