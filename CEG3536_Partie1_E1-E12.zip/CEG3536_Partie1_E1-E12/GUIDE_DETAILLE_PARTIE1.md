# CEG 3536 — Partie I : guide de réalisation E1 à E12

Ce guide accompagne le code du laboratoire 4. Il explique **où regarder, quoi faire, ce qui doit apparaître et quelle preuve conserver**. Les tests sur ordinateur sont faits; les mesures sur la carte Nucleo-L552ZE-Q et les contrôles des modules ne le sont pas. Ne présenter aucune valeur estimée comme une mesure réelle.

## A. Préparation commune à tous les essais

1. Extraire entièrement ce ZIP. Conserver les dossiers Core, Drivers, hote et les fichiers .project et .cproject : ils constituent **un projet STM32CubeIDE complet**.
2. Dans STM32CubeIDE 2.2.0 : File → Import → General → Existing Projects into Workspace → Next → Select root directory → sélectionner le dossier extrait → Finish. Mettre la configuration sur Debug, puis Project → Build Project. Si le compilateur signale une erreur, la corriger avant de continuer.
3. Brancher la Nucleo par ST-LINK. Plateforme à plat, arbre de sortie dégagé, potentiomètre Speed au minimum, E-Stop accessible. Ne jamais connecter ou déconnecter un module pendant que le circuit est alimenté.
4. Dans l'IDE, Run → Debug As → STM32 C/C++ Application, puis Resume. Ouvrir Tera Term, PuTTY ou un terminal équivalent sur le port COM du ST-LINK à **115200 bauds, 8N1, sans contrôle de flux**. Au démarrage, attendre une ligne H, une ligne I, puis cinq lignes T par seconde.
5. Pour les tests sans carte : installer GCC et Make (sur Windows, MSYS2 MinGW64; sur Linux, le gestionnaire de paquets). Ouvrir un terminal dans le sous-dossier hote et exécuter **make evq tableau**. Résultats vérifiés pendant cette préparation : file 9/9 cas; tableau 6/6 cas.
6. Pour enregistrer les trames, installer Python 3 et pyserial par la commande **python -m pip install pyserial**. Depuis hote, faire **python telemetrie.py COM8 --duree 30 --sauver preuves/t9.log** en remplaçant COM8 par votre port. Sous Linux, remplacer COM8 par le vrai /dev/ttyACM... .
7. Pour chaque exigence, conserver : une capture datée du terminal, une photo du matériel ou une capture des registres, une ligne « réussite/échec » dans JOURNAL.md et une validation Git correspondant à votre contribution. Un résultat attendu **n'est pas** une observation.

### Commandes à taper dans le terminal série

| Touche | Effet | Résultat attendu |
|---|---|---|
| a | Relevés bruts et mV de l'ADC | plusieurs lignes A |
| q | Test de la file | Q,echecs=0 |
| x | Test des cinq XOR assembleur | X,echecs=0 |
| f | Test du tableau de bord | F,echecs=0 |
| i | Nouveau balayage I2C | I,5,2D,38,39,3E,5A suivi du checksum |
| d | LCD virtuellement absent pendant 2 secondes | erreurs I2C puis reprise |
| t | 40 événements en rafale depuis main | débordement compté |
| b | Comparaison C/assembleur du lab 3 | seulement à l'arrêt |
| z | Réinitialisation des compteurs | Z,ok |

Les lignes T ont 17 champs de données et se terminent par un astérisque et deux chiffres hexadécimaux de contrôle. Les lignes E sont les événements horodatés.

## E1 — Bus I2C2 (T1)

**Fichiers :** Core/Src/i2c.c, Core/Inc/i2c.h, Core/Inc/lab4.h, Core/Src/main.c.

1. Ouvrir i2c_init : RCC active GPIOF et I2C2; PF0 et PF1 sont configurées en AF4 et drain ouvert. Vérifier au débogueur que GPIOF → IDR a ses bits 0 et 1 à **1 au repos**.
2. Dans I2C2 → TIMINGR, vérifier **0x00420F13** (horloge noyau 4 MHz). Calculer le pas = 1/4 MHz = 250 ns; SCLL = 19, donc environ 5 µs bas; SCLH = 15, donc environ 4 µs haut, auxquels s'ajoutent les délais de synchronisation. Mesurer réellement 90 à 100 kHz.
3. Réinitialiser et vérifier la ligne I : exactement cinq adresses hexadécimales **2D,38,39,3E,5A**. Si une adresse manque, revoir le câblage hors tension et l'adressage 7 bits.
4. Mettre un point d'arrêt avant et après une écriture I2C de deux octets de données. Observer DWT → CYCCNT et calculer microsecondes = (après − avant) / 4 à 4 MHz. Une transaction de 3 octets sur le bus prend approximativement 290 µs; inscrire **votre** valeur.
5. Au débogueur, tenter une écriture vers une adresse absente : I2C_NACK, i2c_erreurs incrémenté, I2C2 → ISR ne reste pas en BUSY. Vérifier aussi les branches BERR, ARLO et le délai de 2 ms. Les fonctions écrire, lire et écrire-lire avec redémarrage sont toutes dans i2c.c.
6. **Preuves :** capture I, TIMINGR, GPIOF-IDR, mesure DWT, NACK et état BUSY.

## E2 — Huit DEL et huit commutateurs (T2)

**Fichiers :** ioexp.c (objet par extenseur), tableau.c (image des DEL), main.c (scrutation/anti-rebond).

1. Observer x_del à l'adresse 0x38 et x_commut à 0x39. Les sorties des DEL sont actives à **0** : 0xFF les éteint toutes. L'image logique Y1–Y4/R1–R4 est inversée avant écriture.
2. Vérifier que l'extenseur des commutateurs reçoit 0xFF au début, puis que main.c le lit toutes les **10 ms**.
3. Mettre le système en AUTONOME si nécessaire, puis appuyer/relever SW1 **20 fois**. Compter exactement 20 événements EV_COMMUT de type 10, valeur 1, sans événement supplémentaire au relâchement : l'anti-rebond correspond à 3 lectures stables, soit environ **30 ms**.
4. Tester deux commutateurs simultanément; chaque pression validée doit produire un événement. Observer avec le débogueur les champs ecritures, sortie et sortie_connue de x_del : aucune réécriture de la même image.
5. **Preuves :** photo des DEL, 20 lignes E, compteur des transactions et capture des deux objets.

## E3 — LCD, pages et rétroéclairage RVB (T3)

**Fichiers :** lcd.c, tableau.c, tableau_pres.c, hote/test_tableau.c.

1. Commencer par **make tableau** : les six cas doivent réussir. La fonction tableau_formater ne lit aucun registre et donne exactement deux chaînes de 16 caractères.
2. À l'allumage, lcd_init prévoit **50 ms** de stabilisation; lcd_step émet progressivement 0x28, 0x0C, 0x01, puis 0x06 en respectant la pause de 2 ms après l'effacement.
3. Afficher la page de conduite : ligne 1 « MAN -- ARRET », ligne 2 « C000% V   0.0 PX » lorsque la consigne est nulle. La vitesse, le sens, le mode et le plafond évoluent avec le véhicule.
4. Appuyer SW8 pour les capteurs : exemples « T 23.4C  H 45.2% » et « P1003.2hPa A24.1 »; tant que la mesure SPI est invalide, des tirets remplacent les valeurs.
5. Vérifier à l'arrêt et dans les deux sens que la couleur du LCD correspond à la DEL Nucleo (rouge, vert, bleu). E-Stop et arrêt sur événement doivent clignoter. Modifier la consigne pour confirmer que seuls les caractères modifiés sont réécrits.
6. **Preuves :** sortie make tableau, photos de deux pages, photos des couleurs, absence de scintillement.

## E4 — TouchPad, interruption et garde Touch En (T4)

**Fichiers :** touchpad.c, exti_l4.s, registres_lab4.inc, main.c.

**Important :** le tableau tp_table dans touchpad.c est **provisoire**. Il faudra relever la vraie correspondance des 12 électrodes sur votre carte. Sans cette mesure, E4 n'est pas validé.

1. Examiner tp_init : reset 0x80=0x63, arrêt 0x5E=0, seuils toucher=12/relâcher=6 pour les 12 électrodes, filtres, activation finale 0x5E=0x8C.
2. Dans Debug → Expressions, suivre thi_flag, tp_avant et tp_apres lors d'un appui. Toucher séparément les 12 touches et noter **symbole, bit qui devient 1, code attendu** : chiffres 0..9, Fn=10, Next/Back=11.
3. Corriger tp_table selon **ces observations**. Dans registres_lab4.inc, THI_FRONT_MONTANT est initialement 0 (front descendant); vérifier au débogueur que PB6 déclenche réellement EXTI6 et changer ce paramètre si le signal indique un front différent.
4. Activer le bouton physique Touch En (Y3 allumée), puis presser une touche brièvement et la maintenir : un seul événement E de type 8 doit apparaître, sans répétition. Toucher deux touches ensemble : aucune touche acceptée.
5. Désactiver Touch En et presser une touche : aucune commande, « VERROU » pendant 1 s; dans Debug, touches_refusees augmente.
6. **Preuves :** tableau réel des 12 touches, capture EXTI6, E de type 8, refus et message VERROU.

## E5 — Plafond du TouchPad et sélection MANUEL/AUTONOME (T5)

**Fichier :** fsm.c, variables dans lab3.h et lab4.h.

1. Activer Touch En et démarrer MANUEL en sécurité, potentiomètre initialement bas.
2. Toucher successivement **5, 9, 0** en augmentant progressivement la consigne : plafond_pct prend **50 %, 90 %, 100 %**. Le PWM suit le plafond avec la rampe (un point de pourcentage toutes les 10 ms), sans saut brusque.
3. Arrêter par User. Presser Next/Back : mode 0 (MANUEL) devient 1 (AUTONOME), DEL Y2. Redémarrer et réessayer Next/Back : refus en marche.
4. Vérifier un bip court pour chaque touche acceptée, la consigne plafonnée dans T et les valeurs sur le LCD.
5. **Preuves :** lignes T montrant plafond_pct, mode, consigne_pct et pwm_pct; photo Y2/Y3.

## E6 — PIR et arrêt sur interruption EXTI9 (T6)

**Fichiers :** exti_l4.s, main.c, fsm.c.

1. Vérifier que EXTI9 est sélectionnée sur PB9, front montant. Le gestionnaire assembleur mémorise pir_t_ms, lève pir_flag, ignore les fronts survenant à moins de **50 ms**, efface RPR1/FPR1; il ne réalise aucune transaction I2C.
2. Plateforme à plat, arbre **dégagé**. Démarrer le moteur à faible vitesse et faire passer la main **au-dessus de la lentille**, jamais près de l'arbre.
3. Attendre l'événement E de type 9. Vérifier CCR1=0, STB=0, R2, « OBSTACLE », DEL rouge et les bips. Calculer le délai entre pir_t_ms et coupure : **moins de 100 ms**, avec relevés horodatés.
4. Essayer Fn tant que PB9 est à 1 : pas de reprise. Une fois PB9 à 0, Fn ramène à ARRÊT, puis User peut relancer.
5. **Preuves :** pir_t_ms, registre EXTI, CCR1, chronométrage et photo des indicateurs.

## E7 — Capteur environnemental sur SPI1 (T7)

**Fichiers :** spi.c, env.c, bme680_comp.c (formules fournies, ne pas modifier).

1. Vérifier PA5 SCK / PA6 MISO / PA7 MOSI en AF5, PD14 CS à 1 au repos, SPI1 maître 8 bits, horloge d'au plus 1 MHz.
2. En Debug, env_identifiant() doit lire **0x61** depuis le registre 0xD0. Si l'identifiant est faux, vérifier d'abord CS, le choix des pages SPI et le bit lecture.
3. Le pilote récupère 41 octets de calibration, déclenche une conversion forcée toutes les **1000 ms**, attend new_data sans délai actif et convertit T/H/P par les formules entières fournies.
4. Relever les trois colonnes environnementales de T et la page capteurs : température à moins de 3 °C du capteur analogique, humidité 10–90 %, pression 950–1050 hPa.
5. Souffler doucement vers le capteur pendant 10 s, sans le toucher; l'humidité doit monter. À plus de 70 %, Y1 s'allume et la consigne est limitée; la limitation se lève sous 65 %.
6. **Preuves :** ID 0x61 observé, CR1/CR2/SR de SPI1, mesures T/H/P avant et après.

## E8 — Autonomie et événements routiers simulés (T8)

**Fichiers :** fsm.c, main.c et tableau.c.

1. À l'arrêt, avec Touch En actif, presser Next/Back pour AUTONOME. Y2 s'allume, le potentiomètre n'agit plus sur la consigne de base **60 %**.
2. Démarrer avec User. SW3 active la limite **30 %** (Y1). SW1 allume R1 et arrête sur FEU ROUGE. Désactiver SW1, presser Fn, puis User pour reprendre.
3. Tester SW2 = OBSTACLE, SW4 = FIN (arrêt sans acquittement), SW5 = DÉFAUT. Les commutateurs sont à bascule : un second appui retire la condition. Photographier l'indication.
4. Revenir en MANUEL à l'arrêt et refaire SW1–SW5 : pas d'effet sur le déplacement. Le PIR réel et E-Stop restent prioritaires.
5. **Preuves :** captures mode/cause/plafond, Y1/Y2/R1/R2/R3/Y4, traces des commutateurs.

## E9 — Machine à états, priorités et reprise (T8)

**Fichier :** fsm.c, fonctions fsm_traiter, priorites et fsm_sorties.

1. Relever l'ordre exigé : E-Stop > défaut > obstacle (PIR ou SW2) > feu (SW1) > limitation > consigne. Déclencher SW1 et SW2, puis SW5 : vérifier que la cause affichée est la plus importante active.
2. Dans un état d'arrêt sur événement, contrôler CCR1=0 et STB=0. Essayer User : aucun redémarrage. Enlever toutes les causes encore actives, puis Fn : retour en ARRÊT; **un nouvel User** est nécessaire.
3. E-Stop agit dans tous les modes, y compris lorsque les événements SW1/SW2 sont actifs. L'acquittement de l'urgence exige d'abord le relâchement d'E-Stop, puis Fn ou Touch En.
4. Vérifier avec les registres et une photo qu'AI1 et AI2 ne sont jamais à 1 en même temps et que le sens change uniquement depuis ARRÊT avec CCR1=0.
5. **Preuves :** séquence de lignes E et T, captures de l'état/cause et de la sortie moteur.

## E10 — Assembleur et télémétrie avec XOR (T9)

**Fichiers :** somme.s, exti_l4.s, somme_test.c, telem.c.

1. La fonction assembleur trame_xor8 lit exactement n octets par LDRB, combine par EOR, retourne en R0; n=0 doit rendre 0 sans accès à un octet. Taper **x**, attendre **X,echecs=0**.
2. Les cinq vecteurs attendus sont : vide 00; A 41; T,0 48; 123456789 31; tous les octets 00..FF 00. Comparer tableau attendu et obtenu.
3. Observer un passage du gestionnaire assembleur EXTI9 ou EXTI6 au débogueur, ainsi que l'effacement de sa requête.
4. Enregistrer 30 s via telemetrie.py : **135 à 165 trames**, toutes au format T avec *HH valide, aucune ligne tronquée; lignes E pour PIR, touches, commutateurs et E-Stop.
5. **Preuves :** autotest, capture R0/R1/registre, log 30 s, rapport telemetrie.py.

## E11 — Temps réel et non-régression (T10)

**Fichiers :** main.c, lcd.c, i2c.c et anciens pilotes du lab 3.

1. Lire l'arbitrage après tableau_step : un seul choix entre lecture THI, lecture SW toutes les 10 ms, écriture des DEL modifiées, lcd_step. Aucun bus I2C n'est utilisé dans les interruptions. SPI reste indépendant.
2. Mesurer ticks_perdus dans les lignes T en fonctionnement normal : il doit rester **0**. La commande de diagnostic i refait 112 transactions et peut provoquer des ticks manqués; éviter de la lancer pendant la mesure de cadence.
3. Refaire le cycle User → avant → arrêt → arrière → arrêt; contrôler potentiomètre en MANUEL. Tester E-Stop et la coupure moteur en **moins de 1 ms**.
4. Exécuter les tests hôte sur Windows **et** Linux (au minimum make evq tableau), puis f sur la cible.
5. **Preuves :** logs de ticks, tests, E-Stop, captures de la PWM.

## E12 — Pannes simulées et robustesse (T10)

**Fichiers :** i2c.c, lcd.c, main.c, fsm.c.

1. En fonctionnement normal, taper **d** : le LCD adresse 0x3E répond comme absent pendant 2 s; lcd_init force des tentatives; i2c_erreurs et l'indication de défaut doivent augmenter.
2. Après les 2 s, le LCD doit se restaurer **sans NRST**. Vérifier la DEL R3, l'état de défaut, la possibilité d'acquitter lorsque la panne a disparu.
3. Pendant la simulation, déclencher E-Stop : la coupure doit toujours être immédiate. Tester PIR lors d'un appui TouchPad, deux commutateurs ensemble, et la commande **t** pour saturer la file.
4. Vérifier : aucune trame T tronquée, bus jamais bloqué, aucune reprise sans Fn/Touch En et sorties moteur sûres.
5. **Limite à vérifier et possiblement compléter sur banc :** si le TouchPad devient totalement silencieux, la seule interruption THI ne permet pas de constater ses trois échecs; prévoir une lecture périodique de diagnostic si ce cas doit être évalué. Ne pas le déclarer réussi sans essai.
6. **Preuves :** lignes T et E avant/panne/après, compteur d'erreurs, captures de la reprise.

## Composante L4-A — enquête du pilote volontairement défectueux

La variante **L4A_VARIANTE (0, 1, 2 ou 3)** est attribuée par le professeur sur Brightspace; elle n'est pas fournie dans les trois fichiers joints. Il serait incorrect de choisir arbitrairement votre variante ou d'inventer les mesures.

1. Vérifier votre numéro et le mettre dans Core/Inc/lab4.h. Conserver le pilote fourni **l4a_defaut.c** intact dans un premier commit Git (par exemple l4a_avant). Pour l'essai seulement, remplacer les appels tp_init/tp_lire dans main.c par l4a_tp_init/l4a_tp_lire, recompiler, puis relever le symptôme.
2. **Avant les mesures**, écrire dans JOURNAL.md le symptôme reproductible et au moins **trois hypothèses ordonnées** : problème des lignes SDA/SCL et broches; adresse/protocole; séquence de registres/seuils; interruption et garde Touch En.
3. Pour chaque hypothèse, choisir une mesure qui peut l'écarter : PF0/PF1 au repos; I2C2 → ISR/CR2; balayage i; relecture du registre 0x5E; lecture des deux octets 0x00/0x01; état thi_flag et registres EXTI.
4. **Avant l'essai discriminant**, écrire : « si H1 est vraie, résultat X; si H2 est vraie, résultat Y ». Réaliser l'essai, noter les valeurs, exclure les hypothèses non compatibles.
5. Corriger uniquement la cause démontrée dans l4a_defaut.c, en **second commit distinct**; refaire E4/T4 avec la version corrigée; conserver les preuves et les limites de la conclusion.
6. Rédiger le rapport dans cet ordre : symptôme → hypothèses → tests → essai discriminant → interprétation → correction → non-régression → limites. Ne pas remplacer le pilote défectueux par le pilote normal de l'équipe.

## Liste finale avant la démonstration intermédiaire

- [ ] T1 : cinq adresses, TIMINGR, DWT, NACK.
- [ ] T2 : 20 appuis, huit DEL, anti-rebond.
- [ ] T3 : 2 pages, rétroéclairage, 6 tests hôte.
- [ ] T4 : **table des 12 touches réellement relevée**, THI, garde.
- [ ] T5 : plafonds 50/90/100 et mode à l'arrêt.
- [ ] T6 : PIR, moins de 100 ms, pas de reprise prématurée.
- [ ] T7 : ID SPI 0x61, T/H/P plausibles, variation d'humidité.
- [ ] T8 : SW1–SW5, priorités, Fn, MANUEL sans effet SW.
- [ ] T9 : x = 0 échec, 30 s de trames valides.
- [ ] T10 : d, E-Stop, rafale, ticks_perdus=0, tests hôte.
- [ ] L4-A : variante exacte, hypothèses avant mesures, Git avant/après.

**Dépannage rapide :** LCD vide → vérifier l'adresse 0x3E et lcd_echecs; absence de touches → contrôler EXTI6 et tp_table; I2C manquant → PF0/PF1 et les tirages; T/H/P à zéro → PD14, SPI1, identifiant et pages; moteur anormal → E-Stop, ne pas poursuivre en mouvement.

**État vérifié :** tests hôte 9/9 et 6/6 réussis; analyse syntaxique C réalisée. **État non vérifié :** compilation ARM intégrale, essais électriques T1–T10, mesures chronométrées, mapping tactile, diagnostic L4-A. Le guide explique comment réaliser ces validations obligatoires.

L'énoncé exige de **déclarer l'utilisation d'IA générative** dans le rapport. Il exige aussi **un seul ZIP final complet** sur Brightspace, même si vous avez demandé ici deux ZIP de travail séparés.
